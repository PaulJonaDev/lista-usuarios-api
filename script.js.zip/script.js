document.addEventListener('DOMContentLoaded', () => {
    const userList = document.getElementById('userList');
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const sortBy = document.getElementById('sortBy');
    const loadingSpinner = document.getElementById('loading');
    
    let users = [];
    let filteredUsers = [];

    const nombresLatinos = [
        "Carlos Rodríguez", "Ana María González", "José Luis Martínez", 
        "María Fernanda Silva", "Juan Carlos Pérez", "Laura Ramírez",
        "Diego Hernández", "Valentina Torres", "Andrés Morales", "Isabella López"
    ];

    const empresasLatinas = [
        "Grupo Bimbo", "Mercado Libre", "CEMEX", "América Móvil", 
        "Falabella", "Banco Santander", "Empresas COPEC", "Grupo Televisa",
        "Grupo Modelo", "Natura & Co"
    ];

    async function fetchUsers() {
        try {
            showLoading(true);
            const response = await fetch('https://jsonplaceholder.typicode.com/users');
            if (!response.ok) throw new Error('Error en la respuesta de la red');
            
            let fetchedUsers = await response.json();
            users = fetchedUsers.map((user, index) => ({
                ...user,
                name: nombresLatinos[index],
                company: { ...user.company, name: empresasLatinas[index] }
            }));
            
            filteredUsers = [...users];
            updateUserList();
        } catch (error) {
            showError('Error al cargar usuarios: ' + error.message);
        } finally {
            showLoading(false);
        }
    }

    function updateUserList() {
        userList.innerHTML = '';
        filteredUsers.forEach(user => {
            const userCard = createUserCard(user);
            userList.appendChild(userCard);
            // Agregamos animación de entrada
            setTimeout(() => userCard.classList.add('visible'), 100);
        });
    }

    function createUserCard(user) {
        const userCard = document.createElement('div');
        userCard.className = 'user-card';
        userCard.innerHTML = `
            <h2>${user.name}</h2>
            <p class="user-info"><strong>Email:</strong> ${user.email}</p>
            <p class="user-info"><strong>Teléfono:</strong> ${user.phone}</p>
            <p class="user-info"><strong>Sitio web:</strong> ${user.website}</p>
            <p class="user-info"><strong>Empresa:</strong> ${user.company.name}</p>
        `;
        return userCard;
    }

    function filterUsers() {
        const searchTerm = searchInput.value.toLowerCase();
        filteredUsers = users.filter(user => 
            user.name.toLowerCase().includes(searchTerm) ||
            user.company.name.toLowerCase().includes(searchTerm)
        );
        updateUserList();
    }

    function sortUsers(criteria) {
        filteredUsers.sort((a, b) => {
            switch(criteria) {
                case 'name':
                    return a.name.localeCompare(b.name);
                case 'email':
                    return a.email.localeCompare(b.email);
                case 'company':
                    return a.company.name.localeCompare(b.company.name);
                default:
                    return 0;
            }
        });
        updateUserList();
    }

    function showLoading(show) {
        loadingSpinner.style.display = show ? 'block' : 'none';
        userList.style.opacity = show ? '0.5' : '1';
    }

    function showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        userList.innerHTML = '';
        userList.appendChild(errorDiv);
    }

    // Event Listeners con debounce para mejor rendimiento
    let searchTimeout;
    searchInput.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(filterUsers, 300);
    });

    searchButton.addEventListener('click', filterUsers);

    sortBy.addEventListener('change', () => sortUsers(sortBy.value));

    // Inicializar la aplicación
    fetchUsers();
});