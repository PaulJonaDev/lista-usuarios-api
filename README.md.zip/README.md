# Lista de Usuarios - Aplicación Web

## 1. Descripción General del Proyecto
- Es una aplicación web que muestra una lista de usuarios
- Consume datos de la API JSONPlaceholder
- Presenta la información en una interfaz visual agradable

## 2. Características Principales
- Obtiene datos de usuarios de una API externa
- Muestra los usuarios en tarjetas organizadas en una cuadrícula 3x3
- Permite buscar usuarios por nombre o empresa
- Incluye opciones para ordenar los usuarios
- Diseño responsive que se adapta a diferentes tamaños de pantalla

## 3. Tecnologías Utilizadas
- HTML5 para la estructura
- CSS3 con Grid y Flexbox para el diseño
- JavaScript vanilla para la funcionalidad
- Font Awesome para los iconos

## 4. Estructura del Proyecto
- `index.html`: Contiene la estructura de la página
- `styles.css`: Maneja todos los estilos y diseño visual
- `script.js`: Contiene la lógica de la aplicación

## 5. Manejo de Errores
- Incluye mensajes de error amigables
- Muestra un spinner de carga mientras se obtienen los datos
- Maneja posibles fallos en la conexión con la API

## 6. Cómo Ejecutar el Proyecto
- Solo necesitas abrir el archivo index.html en un navegador web
- No requiere instalación de dependencias adicionales

## 7. Demo de la Aplicación
[Ver Demo en Video](demo-app.mov)